<?php

namespace App\Http\Controllers\Api\Category;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Botble\Ecommerce\Models\Customer;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Client;
use Botble\Ecommerce\Models\ProductCategory;

class CategoryController extends Controller
{
  

   public function get_categories()
   {

        $categories = ProductCategory::query()
            ->orderBy('order')
            ->orderByDesc('created_at')
            ->with('slugable')
            ->withCount('products')
            ->paginate();
     
     
    
       return response()->success($categories, __('Reports Found'));

    }


  



}
